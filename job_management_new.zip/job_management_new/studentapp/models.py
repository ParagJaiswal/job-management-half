from django.db import models

class StudentReg(models.Model):
	Email = models.CharField(max_length=30)
	Password = models.CharField(max_length=15)
	Mobile= models.CharField(max_length=13)
	Branch = models.CharField(max_length=20)
	Status =models.CharField(max_length=10)

	def __str__(self):
		return self.Email+" "+ self.Password